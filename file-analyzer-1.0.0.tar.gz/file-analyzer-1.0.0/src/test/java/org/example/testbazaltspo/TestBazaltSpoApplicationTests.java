package org.example.testbazaltspo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestBazaltSpoApplicationTests {

    @Test
    void contextLoads() {
    }

}
